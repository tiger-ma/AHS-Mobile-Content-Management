package com.tiger;

public class FunUtils{
        public static String makeItLower(String data){
                return data.toLowerCase();
        }
}

